import Cocoa

/*
    This playground parses the backgrounditems.btm file and produces a
    readable output of all Login Items for the user account that owns that file.
    
    Note, that "Login Items" is a specific mechanism for persistence
    defined by Apple and is unrelated to any other means of persistence
    like LaunchAgents, etc.
 */


// grab the login items .btm file from the account you're running this code on
let backgroundbtmFile = String(format:"%@/Library/Application Support/com.apple.backgroundtaskmanagementagent/backgrounditems.btm", NSHomeDirectory())

/*
 Or if you have the file from another machine saved locally, comment out above and
 add the path to the file below and uncomment.
*/

// let backgroundbtmFile = // path to file

if let theData = FileManager.default.contents(atPath: backgroundbtmFile)
{
    do {
        let newValue = try PropertyListSerialization.propertyList(from: theData, options:PropertyListSerialization.ReadOptions(), format:nil)
        let pListDict = newValue as! NSDictionary
        
        if let smg : NSArray = pListDict.value(forKey: "$objects") as? NSArray
        {
            var bookmark : Data = Data()
            var objStr = " "
            for s in smg
            {
                if s is Data
                {
                    bookmark = s as? Data ?? Data()
                } else if s is NSDictionary
                {
                    if let s_ = s as? NSDictionary
                    {
                        if let d = s_.value(forKey:"NS.data")
                        {
                            bookmark = d as? Data ?? Data()
                        }
                    }
                }
                if bookmark.count != nil
                {
                    let NSURLEnumList = ["NSURLBookmarkAllPropertiesKey"]
                    if let loginItemDict = NSURL.resourceValues(forKeys: [URLResourceKey.pathKey], fromBookmarkData: bookmark)
                    {
                            if let li_p = loginItemDict[URLResourceKey.pathKey]
                            {
                                let loginItemStr_untrim = li_p as? String ?? " "
                                let loginItemStr = loginItemStr_untrim.trimmingCharacters(in: .whitespacesAndNewlines)
                                if loginItemStr.count > 2 {
                                    if !objStr.contains(loginItemStr)
                                    {
                                        objStr.append(String(format:"\n\t%@", loginItemStr))
                                        print(loginItemStr)
                                    }
                                }
                        }
                    }
                }
            }
//            userLogins = objStr
                            print(objStr)
        }
    } catch
    {
    
    }
}
